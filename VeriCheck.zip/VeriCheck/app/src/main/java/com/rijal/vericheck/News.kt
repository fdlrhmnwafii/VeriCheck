package com.rijal.vericheck

data class News(
    val title: String,
    val content: String,
    val uploadDate: String)
