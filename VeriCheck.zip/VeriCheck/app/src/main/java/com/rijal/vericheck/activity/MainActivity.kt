package com.rijal.vericheck.activity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.rijal.vericheck.R
import com.rijal.vericheck.databinding.ActivityMainBinding
import com.rijal.vericheck.fragment.AboutFragment
import com.rijal.vericheck.fragment.HelpFragment
import com.rijal.vericheck.fragment.HomeFragment
import com.rijal.vericheck.fragment.ProfileFragment
import com.rijal.vericheck.fragment.ValidasiFragment

class MainActivity : AppCompatActivity() {

    val fragmentHome: Fragment = HomeFragment()
    val fragmentValidasi: Fragment = ValidasiFragment()
    val fragmentAbout: Fragment = AboutFragment()
    val fragmentHelp: Fragment = HelpFragment()
    val fragmentProfile: Fragment = ProfileFragment()
    val fm: FragmentManager = supportFragmentManager
    var active: Fragment = fragmentHome

    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var menu: Menu
    private lateinit var menuItem: MenuItem

    lateinit var binding: ActivityMainBinding

    //menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.logout -> {
                // Misalnya, keluar dari sesi pengguna atau tampilkan dialog konfirmasi logout
                // Kemudian, panggil finish() untuk menutup aplikasi
                Handler(Looper.getMainLooper()).postDelayed({
                    finish()
                }, 500)
                return true
            }

            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        buttonNavigation()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option, menu)
        return true
    }

    private fun buttonNavigation() {
        fm.beginTransaction().add(R.id.container, fragmentHome).show(fragmentHome).commit()
        fm.beginTransaction().add(R.id.container, fragmentValidasi).hide(fragmentValidasi).commit()
        fm.beginTransaction().add(R.id.container, fragmentHelp).hide(fragmentHelp).commit()
        fm.beginTransaction().add(R.id.container, fragmentAbout).hide(fragmentAbout).commit()
        fm.beginTransaction().add(R.id.container, fragmentProfile).hide(fragmentProfile).commit()

        bottomNavigationView = binding.navView
        menu = bottomNavigationView.menu
        menuItem = menu.getItem(0)
        menuItem.isChecked = true

        bottomNavigationView.setOnNavigationItemSelectedListener { item ->

            when (item.itemId) {
                R.id.navigation_home -> {
                    callFragment(0, fragmentHome)
                }

                R.id.navigation_validasi -> {
                    callFragment(1, fragmentValidasi)
                }

                R.id.navigation_help -> {
                    callFragment(2, fragmentHelp)
                }

                R.id.navigation_about -> {
                    callFragment(3, fragmentAbout)
                }

                R.id.navigation_profile -> {
                    callFragment(4, fragmentProfile)
                }
            }
            false
        }
    }

    private fun callFragment(index: Int, fragment: Fragment) {
        menuItem = menu.getItem(index)
        menuItem.isChecked = true
        fm.beginTransaction().hide(active).show(fragment).commit()
        active = fragment
    }
}
