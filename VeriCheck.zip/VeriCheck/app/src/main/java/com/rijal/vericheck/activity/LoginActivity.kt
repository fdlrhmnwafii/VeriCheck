package com.rijal.vericheck.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.rijal.vericheck.R

class LoginActivity : AppCompatActivity() {
    private val username = "vericheck@gmail.com"
    private val password = "admin"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val txtUser: EditText = findViewById(R.id.txtUser)
        val txtPass: EditText = findViewById(R.id.txtPass)
        val login: Button = findViewById(R.id.login)

        login.setOnClickListener {
            if (txtUser.text.toString().equals(username, ignoreCase = true) &&
                txtPass.text.toString().equals(password, ignoreCase = true)
            ) {
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
            } else {
                Toast.makeText(this@LoginActivity, "Username/Password salah", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}
