package com.rijal.vericheck.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rijal.vericheck.News
import com.rijal.vericheck.NewsAdapter
import com.rijal.vericheck.R

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Inisialisasi data berita
        val newsList = listOf(
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023"),
            News("Headline", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ","1 Desember 2023")
            // Tambahkan berita lainnya sesuai kebutuhan
        )

        // Inisialisasi RecyclerView
        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = NewsAdapter(newsList)

        return view
    }
}
